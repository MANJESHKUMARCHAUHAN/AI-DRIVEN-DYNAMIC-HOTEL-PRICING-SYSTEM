/**
 * Research-level technical deck for the AI-Driven Dynamic Hotel Pricing System.
 *
 * Every number here is read from the project's own artifacts
 * (models/artifacts/training_report_v1.json) or measured on the running stack.
 * Nothing is estimated.
 */

const pptx = require("pptxgenjs");
const pres = new pptx();

// Canvas first -- coordinates past the edge are written, not clamped.
pres.layout = "LAYOUT_WIDE"; // 13.33 x 7.5
pres.author = "Sanchay";
pres.title = "AI-Driven Dynamic Hotel Pricing System";

// --------------------------------------------------------------------------
// Palette -- warm terracotta. Chosen for the subject: six Indian cities,
// heritage-and-leisure hospitality. Swapped into another deck it would read wrong.
// --------------------------------------------------------------------------
const DARK = "2B2118"; // deep espresso -- title & closing
const TERRA = "B85042"; // terracotta -- the dominant accent
const TERRA_D = "8E3B32"; // deeper terracotta
const SAGE = "5E8272"; // supporting green
const SAND = "EFEAD8"; // card fill only, never a full background
const INK = "2B2118";
const MUTED = "776A5F";
const WHITE = "FFFFFF";
const RULE = "DFD8CA";

const H = "Cambria"; // headers  (safe list, QA-reliable)
const B = "Calibri"; // body     (safe list, QA-reliable)

const M = 0.62; // left margin
const W = 13.33 - M * 2; // usable width = 12.09

// --------------------------------------------------------------------------
// Helpers
// --------------------------------------------------------------------------

/** A dark full-bleed slide. */
function darkSlide() {
  const s = pres.addSlide();
  s.background = { color: DARK };
  return s;
}

/** A light content slide with its title already placed. */
function slide(title, kicker) {
  const s = pres.addSlide();
  s.background = { color: WHITE };
  if (kicker) {
    s.addText(kicker.toUpperCase(), {
      x: M, y: 0.34, w: W, h: 0.26,
      fontFace: B, fontSize: 11, bold: true, color: TERRA,
      charSpacing: 1.6, margin: 0,
    });
  }
  s.addText(title, {
    x: M, y: kicker ? 0.62 : 0.44, w: W, h: 1.0,
    fontFace: H, fontSize: 32, bold: true, color: INK, margin: 0,
  });
  return s;
}

/** The repeating motif: a number in a filled terracotta circle. */
function badge(s, n, x, y, opts = {}) {
  const d = opts.d || 0.46;
  s.addShape(pres.ShapeType.ellipse, {
    x, y, w: d, h: d, fill: { color: opts.fill || TERRA },
  });
  s.addText(String(n), {
    x, y, w: d, h: d,
    fontFace: B, fontSize: opts.fs || 15, bold: true,
    color: WHITE, align: "center", valign: "middle", margin: 0,
  });
}

/** A soft card. Background tint + shadow -- never an edge stripe. */
function card(s, x, y, w, h, fill) {
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h, rectRadius: 0.06,
    fill: { color: fill || SAND },
    shadow: { type: "outer", angle: 90, blur: 8, offset: 0.04, opacity: 0.10, color: "000000" },
  });
}

/** Big number + label callout. */
function stat(s, x, y, w, value, label, color) {
  s.addText(value, {
    x, y, w, h: 0.82,
    fontFace: H, fontSize: 40, bold: true, color: color || TERRA,
    align: "center", margin: 0,
  });
  s.addText(label, {
    x, y: y + 0.82, w, h: 0.5,
    fontFace: B, fontSize: 11.5, color: MUTED,
    align: "center", margin: 0,
  });
}

/** A labelled box in a flow diagram. */
function node(s, x, y, w, h, label, sub, fill, fg) {
  s.addShape(pres.ShapeType.roundRect, {
    x, y, w, h, rectRadius: 0.08,
    fill: { color: fill },
    line: { color: fill, width: 1 },
  });
  s.addText(label, {
    x, y: sub ? y + 0.09 : y, w, h: sub ? h * 0.5 : h,
    fontFace: B, fontSize: 11.5, bold: true, color: fg || WHITE,
    align: "center", valign: "middle", margin: 0,
  });
  if (sub) {
    s.addText(sub, {
      x, y: y + h * 0.48, w, h: h * 0.44,
      fontFace: B, fontSize: 9, color: fg || WHITE,
      align: "center", valign: "middle", margin: 0,
    });
  }
}

function arrow(s, x, y, w) {
  s.addShape(pres.ShapeType.rightArrow, {
    x, y, w, h: 0.16, fill: { color: "C7BFB2" },
  });
}

/** Bulleted body text. */
function bullets(s, items, x, y, w, h, size) {
  s.addText(
    items.map((t, i) => ({
      text: t,
      options: { bullet: true, breakLine: i !== items.length - 1 },
    })),
    {
      x, y, w, h,
      fontFace: B, fontSize: size || 13.5, color: INK,
      paraSpaceAfter: 7, margin: 0, valign: "top",
    }
  );
}

const chartFrame = {
  showTitle: false,
  showLegend: false,
  chartColors: [TERRA],
  catAxisLabelColor: MUTED,
  valAxisLabelColor: MUTED,
  catAxisLabelFontFace: B,
  valAxisLabelFontFace: B,
  catAxisLabelFontSize: 11,
  valAxisLabelFontSize: 10,
  valGridLine: { color: RULE, size: 1 },
  catGridLine: { style: "none" },
  dataLabelFontFace: B,
  dataLabelFontSize: 11,
};

// ==========================================================================
// 1. Title
// ==========================================================================
{
  const s = darkSlide();
  s.addText("AI-Driven Dynamic", { x: M, y: 1.62, w: W, h: 0.86, fontFace: H, fontSize: 50, bold: true, color: WHITE, margin: 0 });
  s.addText("Hotel Pricing System", { x: M, y: 2.42, w: W, h: 0.86, fontFace: H, fontSize: 50, bold: true, color: TERRA, margin: 0 });

  s.addText(
    "End-to-end revenue management: streaming ingestion, leakage-free features,\ntwo demand models, and a deterministic pricing engine that can be audited.",
    { x: M, y: 3.5, w: 8.6, h: 0.9, fontFace: B, fontSize: 15, color: "C9BFB2", lineSpacing: 22, margin: 0 }
  );

  const items = [["840", "tests"], ["55%", "better than baseline"], ["~25 ms", "per priced night"], ["12", "REST endpoints"]];
  items.forEach(([v, l], i) => {
    const x = M + i * 2.62;
    s.addText(v, { x, y: 4.78, w: 2.4, h: 0.52, fontFace: H, fontSize: 27, bold: true, color: WHITE, margin: 0 });
    s.addText(l, { x, y: 5.3, w: 2.4, h: 0.34, fontFace: B, fontSize: 11, color: "9C8F82", margin: 0 });
  });

  s.addText("Python · FastAPI · PostgreSQL · Kafka · Prophet · scikit-learn · Streamlit · Docker",
    { x: M, y: 6.5, w: W, h: 0.34, fontFace: B, fontSize: 11.5, color: "776A5F", margin: 0 });

  s.addNotes(
    "Open with the problem, not the stack. 'A hotel room is the most perishable product there is — an unsold room-night is worth exactly zero at midnight and there is no inventory to carry forward.' " +
    "Then the constraint that shaped everything: it has to be explainable, because a price a revenue manager cannot interrogate is a price they will override, and an overridden pricing system is a switched-off pricing system."
  );
}

// ==========================================================================
// 2. The problem
// ==========================================================================
{
  const s = slide("Perishable inventory, and a decision every single day", "The problem");

  bullets(s, [
    "An unsold room-night is worth exactly zero at midnight. There is no inventory to carry forward and no second chance to sell it.",
    "So the system must decide — daily, for every room type and every future night — what to charge, while demand is uncertain and competitors are moving.",
    "The answer changes as check-in approaches: the same night is a different pricing problem 60 days out and 2 days out.",
  ], M, 1.62, 6.9, 2.4, 14);

  s.addShape(pres.ShapeType.roundRect, {
    x: M, y: 4.28, w: 6.9, h: 1.42, rectRadius: 0.08, fill: { color: SAND },
  });
  s.addText("And it has to be explainable.", { x: M + 0.3, y: 4.44, w: 6.3, h: 0.34, fontFace: H, fontSize: 16, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "A price a revenue manager cannot interrogate is a price they will override — and an overridden pricing system is a switched-off pricing system.",
    { x: M + 0.3, y: 4.78, w: 6.3, h: 0.8, fontFace: B, fontSize: 12.5, color: INK, margin: 0 }
  );

  card(s, 7.86, 1.6, 4.85, 4.1, "FBF8F2");
  s.addText("What it manages", { x: 8.16, y: 1.82, w: 4.25, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });

  const rows = [
    ["8", "hotels across 6 Indian cities"],
    ["4", "room categories per property"],
    ["365", "days of history, 312,586 rows"],
    ["30", "engineered features"],
  ];
  rows.forEach(([n, t], i) => {
    const y = 2.34 + i * 0.78;
    badge(s, n, 8.16, y, { d: 0.5, fs: n.length > 2 ? 11 : 14 });
    s.addText(t, { x: 8.82, y: y + 0.04, w: 3.6, h: 0.42, fontFace: B, fontSize: 12.5, color: INK, valign: "middle", margin: 0 });
  });

  s.addText("RevPAR = occupancy × ADR is the number hotels actually manage against.",
    { x: 8.16, y: 5.18, w: 4.25, h: 0.4, fontFace: B, fontSize: 10.5, italic: true, color: MUTED, margin: 0 });

  s.addNotes(
    "Why RevPAR and not occupancy or ADR: occupancy alone rewards giving rooms away, ADR alone rewards an empty hotel with one expensive suite sold. RevPAR is the only one you cannot game by sacrificing the other. " +
    "If asked about the data: it is a simulator, not a random number generator — every relationship the pricing engine later claims to exploit is put there deliberately and asserted in tests."
  );
}

// ==========================================================================
// 3. System at a glance
// ==========================================================================
{
  const s = slide("From a published rate to an auditable price", "Architecture");

  const y1 = 1.72, hb = 0.62;
  node(s, M, y1, 1.86, hb, "Demo OTA", "real site + robots.txt", SAGE);
  arrow(s, M + 1.94, y1 + 0.23, 0.3);
  node(s, M + 2.32, y1, 1.72, hb, "Scraper", "CSS selectors", SAGE);
  arrow(s, M + 4.12, y1 + 0.23, 0.3);
  node(s, M + 4.5, y1, 1.6, hb, "Kafka", "4 topics", SAGE);
  arrow(s, M + 6.18, y1 + 0.23, 0.3);
  node(s, M + 6.56, y1, 1.72, hb, "Consumer", "idempotent", SAGE);
  arrow(s, M + 8.36, y1 + 0.23, 0.3);
  node(s, M + 8.74, y1, 1.9, hb, "PostgreSQL", "9 tables", SAGE);

  const y2 = 2.86;
  node(s, M, y2, 2.5, hb, "Feature pipeline", "30 features, leakage-free", "8C7B6B");
  arrow(s, M + 2.58, y2 + 0.23, 0.3);
  node(s, M + 2.96, y2, 2.1, hb, "Prophet", "calendar structure", "8C7B6B");
  node(s, M + 5.14, y2, 2.1, hb, "Gradient Boosting", "current situation", "8C7B6B");
  arrow(s, M + 7.32, y2 + 0.23, 0.3);
  node(s, M + 7.7, y2, 2.94, hb, "Blended demand + confidence", null, "8C7B6B");

  const y3 = 4.0;
  node(s, M, y3, 3.1, hb, "Pricing engine", "5 clamped adjustments", TERRA);
  arrow(s, M + 3.18, y3 + 0.23, 0.3);
  node(s, M + 3.56, y3, 3.0, hb, "Guardrails", "fixed order, unbypassable", TERRA);
  arrow(s, M + 6.64, y3 + 0.23, 0.3);
  node(s, M + 7.02, y3, 1.7, hb, "FastAPI", null, TERRA);
  arrow(s, M + 8.8, y3 + 0.23, 0.3);
  node(s, M + 9.18, y3, 1.46, hb, "Dashboard", null, TERRA);

  card(s, M, 5.1, W, 1.45, "FBF8F2");
  const rules = [
    ["pricing/ imports no framework", "No FastAPI, no SQLAlchemy, no Kafka. Numbers in, numbers out — so every rule is testable in one line."],
    ["The dashboard has no database", "Every figure comes from an HTTP call, so there is one implementation of \"the right price\", not two."],
    ["Nothing non-deterministic is load-bearing", "The LLM agent is optional by construction; deleting it leaves a working pricing system."],
  ];
  rules.forEach(([t, d], i) => {
    const x = M + 0.26 + i * 3.96;
    s.addText(t, { x, y: 5.28, w: 3.66, h: 0.3, fontFace: B, fontSize: 11.5, bold: true, color: TERRA_D, margin: 0 });
    s.addText(d, { x, y: 5.58, w: 3.66, h: 0.82, fontFace: B, fontSize: 10, color: INK, margin: 0 });
  });

  s.addNotes(
    "Walk left to right, top to bottom — it is one path. The three rules at the bottom are the architectural claims; each is enforced, not aspirational. " +
    "If asked why Prophet AND a gradient booster: they answer different questions. Prophet knows calendar structure but nothing about today; the booster knows today but has no notion of a seasonal cycle."
  );
}

// ==========================================================================
// 4. Repo map
// ==========================================================================
{
  const s = slide("What each module is responsible for", "Codebase");

  const left = [
    ["config/", "One settings tree, entirely from the environment"],
    ["database/", "9 tables, SQLAlchemy 2.0, composite foreign keys"],
    ["demo_ota/", "The competitor website the scraper scrapes"],
    ["ingestion/", "CompetitorScraper interface + 4 implementations"],
    ["streaming/", "Event contracts, producer, consumer, handlers"],
    ["features/", "Calendar, feature pipeline, feature store"],
    ["models/", "Prophet, GBR, metrics, the model registry"],
  ];
  const right = [
    ["training/", "Training pipeline and versioning"],
    ["pricing/", "Rules, demand blending, engine, guardrails"],
    ["api/", "FastAPI — 12 endpoints, schemas, dependencies"],
    ["dashboard/", "Streamlit — 9 pages, Plotly, HTTP only"],
    ["ai_agent/", "Optional LLM agent. Read-only by construction."],
    ["monitoring/", "Logging, data quality, drift, model health"],
    ["scripts/", "Every operation exposed as a CLI"],
  ];

  [left, right].forEach((col, ci) => {
    const x = M + ci * 6.2;
    col.forEach(([name, desc], i) => {
      const y = 1.66 + i * 0.66;
      s.addText(name, { x, y, w: 1.6, h: 0.32, fontFace: "Courier New", fontSize: 12, bold: true, color: TERRA_D, margin: 0 });
      s.addText(desc, { x: x + 1.66, w: 4.1, y, h: 0.42, fontFace: B, fontSize: 11.5, color: INK, margin: 0 });
    });
  });

  s.addText("~31,800 lines across 85 modules — plus 8,650 lines of tests.",
    { x: M, y: 6.42, w: W, h: 0.34, fontFace: B, fontSize: 11.5, italic: true, color: MUTED, margin: 0 });

  s.addNotes(
    "Do not read this list aloud. Use it to answer 'walk me through the codebase' by pointing at the three boundaries: ingestion is swappable behind one interface, pricing is pure, and the dashboard is a pure API consumer. " +
    "The interesting one is pricing/ — it imports no framework at all, which is what lets every pricing rule be tested in a single line and keeps HTTP and ORM concerns out of the part an auditor cares about."
  );
}

// ==========================================================================
// 5. Data + the pickup grid
// ==========================================================================
{
  const s = slide("The booking curve is preserved, not aggregated away", "Data");

  bullets(s, [
    "A simulator, not a random number generator: every relationship the pricing engine later exploits is put there deliberately and asserted in tests.",
    "Stored at room-night grain on the pickup grid — one row per (booking date × stay date).",
    "That single choice is what makes leakage-free features possible: demand for a night can be reconstructed as of any earlier point in time.",
  ], M, 1.62, 6.6, 2.3, 14);

  card(s, M, 4.1, 6.6, 1.72, SAND);
  s.addText("Simpson's paradox, handled explicitly", { x: M + 0.28, y: 4.26, w: 6.05, h: 0.32, fontFace: H, fontSize: 14, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Pooled across room types the occupancy-to-price correlation comes out negative — suites are the least occupied and most expensive, so the between-group effect swamps the within-group one. Tests correlate within (hotel, room_type) and say so in the docstring.",
    { x: M + 0.28, y: 4.6, w: 6.05, h: 1.06, fontFace: B, fontSize: 11, color: INK, margin: 0 }
  );

  card(s, 7.66, 1.6, 5.05, 4.22, "FBF8F2");
  s.addText("Mean occupancy on the books, by horizon", { x: 7.94, y: 1.8, w: 4.5, h: 0.32, fontFace: H, fontSize: 13.5, bold: true, color: INK, margin: 0 });

  const grid = [
    ["Days out", "60", "30", "14", "7", "0"],
    ["Occupancy", "0.033", "0.183", "0.411", "0.529", "0.702"],
    ["corr w/ demand", "0.32", "0.66", "0.67", "0.78", "0.97"],
  ];
  grid.forEach((row, r) => {
    const y = 2.32 + r * 0.5;
    row.forEach((cell, c) => {
      const x = c === 0 ? 7.94 : 9.62 + (c - 1) * 0.62;
      s.addText(cell, {
        x, y, w: c === 0 ? 1.66 : 0.62, h: 0.4,
        fontFace: B, fontSize: c === 0 ? 10.5 : 11,
        bold: r === 0 || c === 0,
        color: r === 0 ? MUTED : (c === 5 && r === 2 ? TERRA : INK),
        align: c === 0 ? "left" : "center", valign: "middle", margin: 0,
      });
    });
  });

  s.addText(
    "By check-in day the rooms already on the books essentially are the answer — correlation 0.97. Any model that does not rank occupancy first at short horizons is wrong.",
    { x: 7.94, y: 4.06, w: 4.5, h: 1.0, fontFace: B, fontSize: 11, color: INK, margin: 0 }
  );

  s.addNotes(
    "The pickup grid is the answer to 'how do you prevent leakage' — it is structural, not a code review habit. " +
    "The counterfactual test: change only FUTURE bookings for a stay date, rebuild the features, and assert nothing that claims to be as-of-today moved. " +
    "The occupancy table is worth memorising — it is the sanity check that told me the model was broken (see the merge_asof slide)."
  );
}

// ==========================================================================
// 6. Features and leakage
// ==========================================================================
{
  const s = slide("Thirty features, and one function that prevents skew", "Feature engineering");

  const groups = [
    ["Booking curve", "On-the-books occupancy at each horizon, pickup pace, days to check-in, lead-time buckets"],
    ["Calendar", "Day of week, month, season one-hots, holiday and local-event scores across six cities"],
    ["Market", "Competitor average / min / max, price-to-competitor ratio, availability pressure"],
    ["Interaction", "occupancy × lead time — the third most important feature, and the revenue-management story"],
  ];
  groups.forEach(([t, d], i) => {
    const x = M + (i % 2) * 6.2;
    const y = 1.66 + Math.floor(i / 2) * 1.34;
    badge(s, i + 1, x, y, { d: 0.44, fs: 13 });
    s.addText(t, { x: x + 0.6, y: y - 0.02, w: 5.2, h: 0.34, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
    s.addText(d, { x: x + 0.6, y: y + 0.34, w: 5.2, h: 0.78, fontFace: B, fontSize: 11.5, color: MUTED, margin: 0 });
  });

  card(s, M, 4.5, W, 1.72, SAND);
  s.addText("Two guarantees, both enforced by code rather than by review", { x: M + 0.3, y: 4.68, w: 11.4, h: 0.34, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Leakage — a counterfactual test changes only future bookings for a stay date, rebuilds the features, and asserts nothing as-of-today moved.",
    { x: M + 0.3, y: 5.06, w: 5.5, h: 0.9, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );
  s.addText(
    "Train/serve skew — the training matrix and the serving row both call the same _add_derived_features. Two implementations of \"what are the features\" is how skew happens.",
    { x: M + 6.0, y: 5.06, w: 5.7, h: 0.9, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );

  s.addNotes(
    "If they ask about leakage, lead with the counterfactual test — it is the strongest thing in this project because it tests the property rather than the implementation. " +
    "The train/serve parity seam matters too: FEATURE_VERSION is stamped into every artifact and validated at load, so a model trained on v1 features cannot silently be served v2 ones."
  );
}

// ==========================================================================
// 7. Two models, two jobs
// ==========================================================================
{
  const s = slide("Two models because they answer different questions", "Modelling");

  const cards = [
    {
      x: M, name: "Prophet", role: "Calendar structure",
      pts: [
        "Weekly shape, trend and holiday effects per (hotel, room type) — 32 series fitted",
        "Produces an 80% uncertainty interval, which becomes the confidence score",
        "Knows nothing about today: no occupancy, no competitor rates",
      ],
      color: SAGE,
    },
    {
      x: M + 6.2, name: "Gradient Boosting", role: "The current situation",
      pts: [
        "30 features: on-the-books occupancy, lead time, market position, events",
        "247 trees selected by early stopping on the holdout",
        "Has no notion of a seasonal cycle — only of the state right now",
      ],
      color: TERRA,
    },
  ];

  cards.forEach((c) => {
    card(s, c.x, 1.62, 5.9, 3.1, "FBF8F2");
    s.addShape(pres.ShapeType.roundRect, { x: c.x, y: 1.62, w: 5.9, h: 0.68, rectRadius: 0.08, fill: { color: c.color } });
    s.addText(c.name, { x: c.x + 0.3, y: 1.62, w: 3.0, h: 0.68, fontFace: H, fontSize: 19, bold: true, color: WHITE, valign: "middle", margin: 0 });
    s.addText(c.role, { x: c.x + 3.2, y: 1.62, w: 2.4, h: 0.68, fontFace: B, fontSize: 11.5, color: WHITE, align: "right", valign: "middle", margin: 0 });
    bullets(s, c.pts, c.x + 0.3, 2.5, 5.3, 2.0, 12);
  });

  card(s, M, 5.0, W, 1.3, SAND);
  s.addText("Blended, then scaled by confidence", { x: M + 0.3, y: 5.16, w: 5.4, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Both are scored on the same chronological holdout — never Prophet's internal backtest — because otherwise the blend weight between them has no basis. The blended demand is then scaled by model confidence with a floor of 0.5, so an unsure model degrades towards the base rate instead of making a confident mistake.",
    { x: M + 0.3, y: 5.5, w: 11.4, h: 0.72, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );

  s.addNotes(
    "'Why two models' is a guaranteed question. The answer is that they are not redundant — one is a time-series model with no situational awareness, the other is situational with no calendar. " +
    "The detail that shows rigour: scoring both on the SAME holdout. If you score Prophet on its own backtest and the booster on a holdout, the blend weight is comparing two different things."
  );
}

// ==========================================================================
// 8. Results vs baseline -- CHART
// ==========================================================================
{
  const s = slide("Every metric is quoted against predict-the-mean", "Results");

  s.addChart(
    pres.ChartType.bar,
    [{ name: "MAE", labels: ["Baseline\n(predict the mean)", "Prophet", "Gradient Boosting"], values: [0.1430, 0.0879, 0.0644] }],
    {
      x: M, y: 1.7, w: 6.5, h: 3.5,
      ...chartFrame,
      barDir: "col",
      chartColors: ["A99C8E", SAGE, TERRA],
      varyColors: true,
      showValue: true,
      dataLabelPosition: "outEnd",
      dataLabelFormatCode: "0.0000",
      valAxisMaxVal: 0.18,
      catAxisLabelFontSize: 10,
    }
  );
  s.addText("Mean absolute error on the holdout — lower is better", { x: M, y: 5.22, w: 6.5, h: 0.3, fontFace: B, fontSize: 10.5, italic: true, color: MUTED, align: "center", margin: 0 });

  card(s, 7.5, 1.7, 5.21, 3.5, "FBF8F2");
  s.addText("The holdout", { x: 7.8, y: 1.9, w: 4.6, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
  const facts = [
    ["Split", "Chronological — never shuffled"],
    ["Train", "9,728 rows to 24 Jun 2026"],
    ["Test", "1,920 rows, the following 60 days"],
    ["R² (GBR)", "0.765, against a baseline of 0.000"],
    ["Interval", "Prophet's 80% band covers 78%"],
  ];
  facts.forEach(([k, v], i) => {
    const y = 2.36 + i * 0.53;
    s.addText(k, { x: 7.8, y, w: 1.3, h: 0.4, fontFace: B, fontSize: 11, bold: true, color: TERRA_D, valign: "middle", margin: 0 });
    s.addText(v, { x: 9.14, y, w: 3.3, h: 0.4, fontFace: B, fontSize: 11, color: INK, valign: "middle", margin: 0 });
  });

  s.addText("55% better", { x: 7.8, y: 5.44, w: 2.4, h: 0.5, fontFace: H, fontSize: 26, bold: true, color: TERRA, margin: 0 });
  s.addText("than predicting the mean —\nthe only comparison that means anything", { x: 10.2, y: 5.42, w: 2.5, h: 0.78, fontFace: B, fontSize: 10.5, color: MUTED, margin: 0 });

  s.addNotes(
    "Say 'against a baseline of' every single time you quote a metric. R² of 0.765 sounds good until you learn what the baseline gets — here it is 0.000 by construction, so the number is meaningful. " +
    "Also volunteer 'chronological split, never shuffled' before you are asked. A random split on time-series data leaks the future into training, and saying it first signals you know that."
  );
}

// ==========================================================================
// 9. Accuracy by lead time -- CHART
// ==========================================================================
{
  const s = slide("The error curve has the shape it should have", "Results");

  s.addChart(
    [
      { type: pres.ChartType.line, data: [{ name: "Model", labels: ["0", "1", "2", "3", "5", "7", "10", "14", "21", "30", "45", "60"], values: [0.0447, 0.0462, 0.0497, 0.0542, 0.0602, 0.0636, 0.0678, 0.0847, 0.0734, 0.0766, 0.0786, 0.0805] }] },
      { type: pres.ChartType.line, data: [{ name: "Baseline", labels: ["0", "1", "2", "3", "5", "7", "10", "14", "21", "30", "45", "60"], values: [0.1443, 0.1415, 0.1535, 0.1488, 0.1577, 0.1306, 0.1381, 0.1441, 0.1318, 0.1509, 0.1273, 0.1438] }] },
    ],
    {
      x: M, y: 1.72, w: 7.6, h: 3.7,
      ...chartFrame,
      chartColors: [TERRA, "A99C8E"],
      showLegend: true,
      legendPos: "t",
      legendFontFace: B,
      legendFontSize: 11,
      lineSize: 3,
      lineSmooth: false,
      valAxisMinVal: 0,
      valAxisMaxVal: 0.18,
    }
  );
  s.addText("MAE by days to check-in", { x: M, y: 5.44, w: 7.6, h: 0.3, fontFace: B, fontSize: 10.5, italic: true, color: MUTED, align: "center", margin: 0 });

  bullets(s, [
    "Most accurate near check-in (MAE 0.045 at 0 days, R² 0.884) because the booking curve has already resolved most of the answer.",
    "Degrades with horizon (0.081 at 60 days) — appropriate uncertainty, not a defect.",
    "The baseline is flat across horizons, which is exactly what predicting a constant should look like.",
  ], 8.5, 1.9, 4.2, 2.6, 12);

  card(s, 8.5, 4.62, 4.21, 1.4, SAND);
  s.addText(
    "A model equally accurate at every horizon would be suspicious, not impressive — it would mean lead time carried no information, which for hotel bookings cannot be true.",
    { x: 8.78, y: 4.8, w: 3.65, h: 1.06, fontFace: B, fontSize: 11, color: INK, margin: 0 }
  );

  s.addNotes(
    "This slide is the answer to 'how do you know the model is good' beyond a single number. The SHAPE is the argument. " +
    "Point at the 14-day bump — it is real, it is in the data, and not pretending it is smooth is more honest than a cleaned-up chart."
  );
}

// ==========================================================================
// 10. Feature importance -- CHART
// ==========================================================================
{
  const s = slide("What the model actually learned", "Results");

  s.addChart(
    pres.ChartType.bar,
    [{
      name: "Permutation importance",
      labels: ["price_to_competitor", "demand_pressure", "historical_demand", "lead_time", "search_demand", "occupancy × lead", "days_to_checkin", "occupancy_rate"],
      values: [0.0039, 0.0045, 0.0056, 0.0071, 0.0073, 0.0080, 0.0147, 0.0298],
    }],
    {
      x: M, y: 1.7, w: 7.1, h: 4.0,
      ...chartFrame,
      barDir: "bar",
      showValue: true,
      dataLabelPosition: "outEnd",
      dataLabelFormatCode: "0.0000",
      catAxisLabelFontSize: 10.5,
      valAxisMaxVal: 0.036,
    }
  );

  bullets(s, [
    "On-the-books occupancy first, days to check-in second, their interaction third.",
    "That is the revenue-management story the whole system was built around — and the model found it in the data rather than being told it.",
    "Permutation importance on the holdout, not scikit-learn's impurity measure, which is biased towards high-cardinality columns.",
  ], 8.1, 1.9, 4.6, 2.8, 12);

  card(s, 8.1, 4.86, 4.61, 1.24, SAND);
  s.addText("Reading this table is how I found a serious bug — see the booking-curve slide.",
    { x: 8.38, y: 5.06, w: 4.05, h: 0.86, fontFace: B, fontSize: 11.5, italic: true, color: TERRA_D, margin: 0 });

  s.addNotes(
    "The important claim: the model was not told that occupancy matters most. It was given 30 features and permutation importance on held-out data ranked them. " +
    "Mention the impurity-measure distinction unprompted — it is a small thing that signals you have read past the tutorial."
  );
}

// ==========================================================================
// 11. The pricing algorithm
// ==========================================================================
{
  const s = slide("Five clamped adjustments, scaled by confidence", "Pricing engine");

  const y = 1.78, bw = 2.24, bh = 0.92;
  const adj = [
    ["Demand", "±25%"], ["Occupancy", "±20%"], ["Competitor", "±15%"], ["Event", "±15%"], ["Season", "±10%"],
  ];
  adj.forEach(([n, c], i) => {
    const x = M + i * (bw + 0.2);
    card(s, x, y, bw, bh, SAND);
    s.addText(n, { x, y: y + 0.14, w: bw, h: 0.34, fontFace: H, fontSize: 14.5, bold: true, color: INK, align: "center", margin: 0 });
    s.addText("clamped " + c, { x, y: y + 0.5, w: bw, h: 0.3, fontFace: B, fontSize: 10.5, color: TERRA_D, align: "center", margin: 0 });
  });

  s.addText("↓  summed into ONE multiplier — additive, never chained", { x: M, y: 2.88, w: W, h: 0.34, fontFace: B, fontSize: 13, bold: true, color: MUTED, align: "center", margin: 0 });

  const flow = [
    ["Base rate", "per hotel × room type", "8C7B6B"],
    ["× multiplier", "1 + Σ clamped adjustments", "8C7B6B"],
    ["× confidence", "floor 0.5", TERRA],
    ["→ RawPrice", "not yet serialisable", TERRA_D],
    ["→ guardrails", "→ FinalPrice", DARK],
  ];
  flow.forEach(([t, d, c], i) => {
    const x = M + i * 2.44;
    node(s, x, 3.34, 2.24, 0.78, t, d, c);
    if (i < flow.length - 1) arrow(s, x + 2.3, 3.65, 0.12);
  });

  card(s, M, 4.42, W, 1.86, "FBF8F2");
  s.addText("Why confidence scaling is the subtle part", { x: M + 0.3, y: 4.6, w: 11.4, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Prophet's interval width becomes a confidence score, and the entire adjustment multiplier is multiplied by it — with a floor of 0.5. So a model that is unsure about a night moves the price only half as far from the base rate as a model that is certain. An uncertain model degrades towards doing nothing, rather than making a confident mistake.",
    { x: M + 0.3, y: 4.96, w: 11.4, h: 0.92, fontFace: B, fontSize: 12.5, color: INK, margin: 0 }
  );
  s.addText(
    "This is also why a wide forecast band is usually the whole explanation for a price that looks unresponsive to obvious demand.",
    { x: M + 0.3, y: 5.86, w: 11.4, h: 0.34, fontFace: B, fontSize: 11, italic: true, color: MUTED, margin: 0 }
  );

  s.addNotes(
    "Two details that get asked about. First: adjustments are ADDITIVE inside one multiplier and each is individually clamped — never chained multiplicatively, because chaining lets three moderate signals compound into an extreme move nobody intended. " +
    "Second: confidence scaling with a floor of 0.5. Explain it as 'the system's willingness to act is proportional to how sure it is'."
  );
}

// ==========================================================================
// 12. Guardrails + the type gate
// ==========================================================================
{
  const s = slide("Guardrails run in a fixed order, unbypassable", "Guardrails");

  const order = [
    ["Low-occupancy block", "No increase below 40% occupancy, whatever the model says"],
    ["Daily change cap", "±15% day over day"],
    ["Competitor bands", "±20% around the market"],
    ["Room floor / ceiling", "Per hotel and category"],
    ["MIN_PRICE / MAX_PRICE", "Absolute, always last"],
  ];
  order.forEach(([t, d], i) => {
    const y = 1.66 + i * 0.82;
    badge(s, i + 1, M, y, { d: 0.46, fs: 14, fill: i < 3 ? TERRA : DARK });
    s.addText(t, { x: M + 0.64, y: y - 0.03, w: 3.3, h: 0.34, fontFace: B, fontSize: 13, bold: true, color: INK, margin: 0 });
    s.addText(d, { x: M + 0.64, y: y + 0.29, w: 5.5, h: 0.34, fontFace: B, fontSize: 10.5, color: MUTED, margin: 0 });
  });

  s.addText("relative rules", { x: M + 4.1, y: 1.68, w: 1.9, h: 0.3, fontFace: B, fontSize: 10, bold: true, color: TERRA, margin: 0 });
  s.addText("absolute rules", { x: M + 4.1, y: 4.94, w: 1.9, h: 0.3, fontFace: B, fontSize: 10, bold: true, color: DARK, margin: 0 });

  card(s, 6.9, 1.62, 5.81, 2.5, SAND);
  s.addText("Order is load-bearing", { x: 7.2, y: 1.8, w: 5.2, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Relative rules run before absolute ones. A floor that a percentage rule can undercut afterwards is not a floor — it is a suggestion. Reversing these two groups produces prices outside MIN_PRICE while every individual rule still reports success.",
    { x: 7.2, y: 2.18, w: 5.2, h: 1.1, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );
  s.addText("44 tests cover the guardrails alone — including a sweep of NaN, infinity, negatives and ₹1e9 through every combination.",
    { x: 7.2, y: 3.3, w: 5.2, h: 0.68, fontFace: B, fontSize: 10.5, italic: true, color: MUTED, margin: 0 });

  card(s, 6.9, 4.34, 5.81, 1.94, DARK);
  s.addText("The type gate", { x: 7.2, y: 4.5, w: 5.2, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA, margin: 0 });
  s.addText(
    "The engine returns RawPrice. Only guardrails.apply() can construct a FinalPrice — it holds a module-private token — and the API will only serialise a FinalPrice.",
    { x: 7.2, y: 4.86, w: 5.2, h: 0.82, fontFace: B, fontSize: 11.5, color: "D8CFC4", margin: 0 }
  );
  s.addText(
    "So \"guardrails always run\" is a property of the type system, not a convention somebody has to remember.",
    { x: 7.2, y: 5.7, w: 5.2, h: 0.44, fontFace: B, fontSize: 11, bold: true, color: WHITE, margin: 0 }
  );

  s.addNotes(
    "The type gate is the single best thing to volunteer in a design discussion. The question 'how do you guarantee guardrails always run' normally gets answered with 'we always call them' — here the answer is that a price that skipped them cannot be represented. " +
    "Same pattern shows up again in the AI agent's allowlist. Make the violating state unrepresentable rather than merely discouraged."
  );
}

// ==========================================================================
// 13. Competitor ingestion / the scraping decision
// ==========================================================================
{
  const s = slide("A real scraper, pointed at a site that permits it", "Ingestion");

  card(s, M, 1.62, 5.9, 2.28, "FBF8F2");
  s.addText("The problem", { x: M + 0.3, y: 1.8, w: 5.3, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
  s.addText(
    "Booking.com and Expedia both disallow the search paths their scrapers would need, in robots.txt. The scraper honours robots.txt — so pointing at them correctly produces ScraperBlocked and collects nothing.",
    { x: M + 0.3, y: 2.16, w: 5.3, h: 1.1, fontFace: B, fontSize: 12, color: INK, margin: 0 }
  );
  s.addText("Two options: delete the check, or scrape something that says yes.",
    { x: M + 0.3, y: 3.3, w: 5.3, h: 0.44, fontFace: B, fontSize: 11.5, italic: true, bold: true, color: TERRA_D, margin: 0 });

  card(s, 6.82, 1.62, 5.89, 2.28, SAND);
  s.addText("The decision", { x: 7.12, y: 1.8, w: 5.3, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "The project ships demo_ota/ — a real web server with real HTML and its own robots.txt that allows /search. The scraper fetches it over the network, reads the policy, parses CSS selectors, respects the rate limiter.",
    { x: 7.12, y: 2.16, w: 5.3, h: 1.1, fontFace: B, fontSize: 12, color: INK, margin: 0 }
  );
  s.addText("Every part of the scraping stack is real. Only the server's owner differs.",
    { x: 7.12, y: 3.3, w: 5.3, h: 0.44, fontFace: B, fontSize: 11.5, italic: true, bold: true, color: TERRA_D, margin: 0 });

  const sources = [
    ["synthetic", "no network", "offline generator, deterministic"],
    ["demo_ota", "REAL scraping", "the default under Docker"],
    ["booking", "third-party", "opt-in twice, robots refuses"],
    ["expedia", "third-party", "opt-in twice, robots refuses"],
  ];
  s.addText("One interface, four implementations — swapping in a licensed feed is one subclass",
    { x: M, y: 4.1, w: W, h: 0.34, fontFace: H, fontSize: 14, bold: true, color: INK, margin: 0 });
  sources.forEach(([n, tag, d], i) => {
    const x = M + i * 3.05;
    card(s, x, 4.54, 2.85, 1.24, i === 1 ? SAND : "FBF8F2");
    s.addText(n, { x: x + 0.2, y: 4.68, w: 2.45, h: 0.3, fontFace: "Courier New", fontSize: 12, bold: true, color: i === 1 ? TERRA_D : INK, margin: 0 });
    s.addText(tag, { x: x + 0.2, y: 4.98, w: 2.45, h: 0.28, fontFace: B, fontSize: 10, bold: true, color: i === 1 ? TERRA : MUTED, margin: 0 });
    s.addText(d, { x: x + 0.2, y: 5.24, w: 2.45, h: 0.46, fontFace: B, fontSize: 10, color: MUTED, margin: 0 });
  });

  s.addText(
    "INGESTION_ENABLE_REAL_SCRAPERS gates third-party terms-of-service risk — not \"does it use HTTP\". Gating demo_ota behind it would put the safe option behind the frightening switch.",
    { x: M, y: 5.94, w: W, h: 0.4, fontFace: B, fontSize: 11, italic: true, color: MUTED, margin: 0 }
  );

  s.addNotes(
    "This is the most distinctive slide in the deck — spend time here. The point is not that I built a scraper; it is that I hit a constraint and chose the option that kept a real guarantee instead of the option that produced a better screenshot. " +
    "If they push: parse() raises ScraperParseError rather than returning an empty list, because to a pricing engine 'the market published no rates' and 'our parser broke' must never look the same. There is a layout=v2 switch that triggers exactly that failure on demand."
  );
}

// ==========================================================================
// 14. Kafka
// ==========================================================================
{
  const s = slide("At-least-once, made safe by idempotent writes", "Streaming");

  const steps = [
    ["Producer publishes", "Each observation is wrapped in an envelope carrying a uuid4 event_id"],
    ["Consumer reads a batch", "Auto-commit is OFF — this is the whole design"],
    ["Handler writes to Postgres", "INSERT ... ON CONFLICT DO NOTHING on the unique event_id"],
    ["Offset committed after the DB commit", "So a crash replays the message rather than losing it"],
  ];
  steps.forEach(([t, d], i) => {
    const y = 1.66 + i * 0.94;
    badge(s, i + 1, M, y, { d: 0.5, fs: 15 });
    s.addText(t, { x: M + 0.68, y: y - 0.02, w: 6.1, h: 0.34, fontFace: B, fontSize: 13.5, bold: true, color: INK, margin: 0 });
    s.addText(d, { x: M + 0.68, y: y + 0.32, w: 6.1, h: 0.4, fontFace: B, fontSize: 11, color: MUTED, margin: 0 });
  });

  card(s, 7.66, 1.62, 5.05, 2.2, DARK);
  s.addText("The trade being made", { x: 7.96, y: 1.8, w: 4.45, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA, margin: 0 });
  s.addText(
    "Committing the offset before the write would be at-most-once: a crash silently loses competitor observations, and the pricing engine keeps quoting a market it can no longer see.",
    { x: 7.96, y: 2.16, w: 4.45, h: 1.5, fontFace: B, fontSize: 11.5, color: "D8CFC4", margin: 0 }
  );

  card(s, 7.66, 4.02, 5.05, 2.26, SAND);
  s.addText("Why event_id is the key", { x: 7.96, y: 4.2, w: 4.45, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "After a consumer rebalance the same message legitimately arrives twice. Without a unique key that is a duplicated observation quietly dragging the competitor average around — a data-quality bug with no error and no log line.",
    { x: 7.96, y: 4.56, w: 4.45, h: 1.6, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );

  s.addNotes(
    "The framing that lands: at-least-once is not a compromise you tolerate, it is a choice you make safe. The unique event_id turns redelivery from a correctness problem into a no-op insert. " +
    "Four topics, single broker with replication factor 1 — correct for local development and explicitly listed as a production gap."
  );
}

// ==========================================================================
// 15. AI agent -- where it fits
// ==========================================================================
{
  const s = slide("The agent explains. The engine decides.", "AI agent");

  card(s, M, 1.62, 5.9, 3.6, "FBF8F2");
  s.addText("Where it deliberately does not go", { x: M + 0.3, y: 1.82, w: 5.3, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
  bullets(s, [
    "Not the pricing calculation — that needs reproducibility, auditability and a 25 ms budget. An LLM gives up all three.",
    "Not the demand forecast — Prophet and the booster are 39% and 55% better than baseline, run in milliseconds, and expose importances.",
    "Not anywhere inside the request path.",
  ], M + 0.3, 2.22, 5.3, 2.0, 11.5);

  s.addShape(pres.ShapeType.roundRect, { x: M + 0.3, y: 4.28, w: 5.3, h: 0.78, rectRadius: 0.06, fill: { color: TERRA } });
  s.addText("Language models are not regressors.", { x: M + 0.3, y: 4.28, w: 5.3, h: 0.78, fontFace: H, fontSize: 15, bold: true, color: WHITE, align: "center", valign: "middle", margin: 0 });

  card(s, 6.82, 1.62, 5.89, 3.6, SAND);
  s.addText("Where it earns its keep", { x: 7.12, y: 1.82, w: 5.3, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText("Every decision is already stored with its full arithmetic. What was missing is language.",
    { x: 7.12, y: 2.2, w: 5.3, h: 0.44, fontFace: B, fontSize: 11.5, italic: true, color: MUTED, margin: 0 });
  bullets(s, [
    "Explaining a decision from the stored breakdown, naming the exact guardrail that changed the number",
    "Triaging correlated monitoring alerts into one root cause",
    "Extracting events from unstructured text — the one use that would improve the model, not just the operator",
  ], 7.12, 2.7, 5.3, 1.9, 11.5);

  s.addShape(pres.ShapeType.roundRect, { x: 7.12, y: 4.5, w: 5.3, h: 0.56, rectRadius: 0.06, fill: { color: "FFFFFF" } });
  s.addText("Read-only. Simulations use persist=false.", { x: 7.12, y: 4.5, w: 5.3, h: 0.56, fontFace: B, fontSize: 12, bold: true, color: TERRA_D, align: "center", valign: "middle", margin: 0 });

  card(s, M, 5.44, W, 0.9, DARK);
  s.addText(
    "The tempting middle position — let the model pick the multipliers and keep the guardrails — is worse than either extreme. Guardrails clamp the output; they cannot detect that the reasoning was wrong.",
    { x: M + 0.3, y: 5.56, w: 11.4, h: 0.66, fontFace: B, fontSize: 12, color: WHITE, margin: 0 }
  );

  s.addNotes(
    "The bottom bar is the strongest single idea in the project — deliver it slowly. A model that hallucinates 'Diwali is next week' produces a price inside every band, confidently justified, and completely wrong. " +
    "Guardrails bound damage. They do not create correctness. That distinction is what separates someone who has deployed an LLM from someone who has read about it."
  );
}

// ==========================================================================
// 16. AI agent -- architecture
// ==========================================================================
{
  const s = slide("Read-only is enforced in code, not in a prompt", "AI agent");

  const layers = [
    ["dashboard/pages/8_AI_Agent.py", "Presentation — the tool trace is rendered beside every answer", "8C7B6B"],
    ["ai_agent/agent.py", "Reasoning — PricingAgent, system prompt, the loop, MAX_ITERATIONS = 12", SAGE],
    ["ai_agent/tools.py", "Capability — 6 tools, and the allowlist that bounds them", TERRA],
    ["FastAPI — the same 12 endpoints the dashboard uses", "No database access, no new subsystem", DARK],
  ];
  layers.forEach(([t, d, c], i) => {
    const y = 1.66 + i * 0.94;
    s.addShape(pres.ShapeType.roundRect, { x: M, y, w: 6.8, h: 0.78, rectRadius: 0.06, fill: { color: c } });
    s.addText(t, { x: M + 0.25, y: y + 0.08, w: 6.3, h: 0.34, fontFace: B, fontSize: 12.5, bold: true, color: WHITE, margin: 0 });
    s.addText(d, { x: M + 0.25, y: y + 0.4, w: 6.3, h: 0.32, fontFace: B, fontSize: 10, color: "EFE7DC", margin: 0 });
  });

  card(s, 7.66, 1.66, 5.05, 2.5, SAND);
  s.addText("The allowlist", { x: 7.96, y: 1.84, w: 4.45, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "A fixed set of (method, path) pairs, checked before any request leaves. Anything else raises ToolCallDenied. Adding a write tool does not quietly start working — it fails until somebody deliberately edits that tuple, which is a diff a reviewer sees.",
    { x: 7.96, y: 2.2, w: 4.45, h: 1.4, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );
  s.addText("persist=false is hardcoded, not a parameter the model can set.",
    { x: 7.96, y: 3.6, w: 4.45, h: 0.44, fontFace: B, fontSize: 11, bold: true, italic: true, color: TERRA_D, margin: 0 });

  card(s, 7.66, 4.36, 5.05, 1.92, "FBF8F2");
  s.addText("Two tiers, on purpose", { x: 7.96, y: 4.54, w: 4.45, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
  s.addText(
    "agent.py is a true agent — the questions cannot be enumerated and each call depends on the last. triage.py is a single call with no tools. Reaching for the agent tier where one call suffices is the commonest way to overpay.",
    { x: 7.96, y: 4.9, w: 4.45, h: 1.24, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );

  s.addText(
    "No RAG and no vector database — the data is structured, so retrieval here is SQL and typed REST. Embedding an exact query to search it approximately would be a downgrade.",
    { x: M, y: 5.58, w: 6.8, h: 0.7, fontFace: B, fontSize: 11, italic: true, color: MUTED, margin: 0 }
  );

  s.addNotes(
    "Volunteer the boundary before they find it: the allowlist is in-process, so it binds this code and not a different process holding the same URL. The complete control is an API credential with no write scope, and this project does not have one because it ships no auth layer. " +
    "Naming your own limitation is worth more than a stronger-sounding claim a reviewer can puncture in one question. " +
    "Also mention: anthropic is not in requirements.txt at all. Delete the package and the pricing system is unchanged."
  );
}

// ==========================================================================
// 17. MLOps + monitoring
// ==========================================================================
{
  const s = slide("Degrade, don't die — and say so out loud", "MLOps & monitoring");

  const left = [
    ["Model registry", "Versioned artifacts, feature_list.json, a training report per run. Resolution order: explicit → MODEL_ACTIVE_VERSION → newest."],
    ["Loading is lazy and never fatal", "A missing artifact is a degraded service on the historical fallback, not a failed boot. An API that refuses to start before it has been trained cannot be deployed before it is trained."],
    ["The feature contract is checked at load", "Not at first request — so a model/feature mismatch surfaces at deploy time, not in production traffic."],
  ];
  left.forEach(([t, d], i) => {
    const y = 1.66 + i * 1.5;
    s.addText(t, { x: M, y, w: 6.2, h: 0.34, fontFace: H, fontSize: 14, bold: true, color: TERRA_D, margin: 0 });
    s.addText(d, { x: M, y: y + 0.34, w: 6.2, h: 1.02, fontFace: B, fontSize: 11.5, color: INK, margin: 0 });
  });

  card(s, 7.2, 1.66, 5.51, 2.24, "FBF8F2");
  s.addText("What is monitored", { x: 7.5, y: 1.84, w: 4.9, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
  bullets(s, [
    "9 data-quality checks — integrity, freshness, competitor coverage, nulls, grain duplication",
    "PSI drift per feature; prediction and price distributions",
    "Guardrail pressure — how often each rule fires",
  ], 7.5, 2.22, 4.9, 1.5, 11);

  card(s, 7.2, 4.1, 5.51, 2.18, DARK);
  s.addText("The caveat it emits about itself", { x: 7.5, y: 4.28, w: 4.9, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA, margin: 0 });
  s.addText(
    "With under two years of history, comparing a 30-day window against a longer reference cannot separate drift from season. August in Goa genuinely does not look like January in Goa.",
    { x: 7.5, y: 4.64, w: 4.9, h: 1.06, fontFace: B, fontSize: 11.5, color: "D8CFC4", margin: 0 }
  );
  s.addText("A system that cries wolf every autumn is a system people mute.",
    { x: 7.5, y: 5.72, w: 4.9, h: 0.4, fontFace: B, fontSize: 11, bold: true, color: WHITE, margin: 0 });

  s.addNotes(
    "The monitoring caveat is worth leading with — it is an example of the system being honest about its own limits in code rather than in a comment. It is emitted as a check, so anyone reading a drift alert sees it. " +
    "'Degrade, don't die' is the design principle: Kafka down means the API still serves; competitor data missing means fall back to the hotel's own recent rate and LOWER the confidence score."
  );
}

// ==========================================================================
// 18. Testing
// ==========================================================================
{
  const s = slide("840 tests in 50 seconds, none needing a server", "Testing");

  const cols = [
    ["Unit", "Pricing rules, guardrails, metrics, feature maths — pure functions, one line each"],
    ["Contract", "Event envelopes, API schemas, the OpenAPI surface asserted as an exact set"],
    ["Integration", "In-memory SQLite with the session dependency overridden; the scraper against a real server on a free port"],
    ["End-to-end", "Every dashboard page executed with Streamlit's AppTest against a live API"],
  ];
  cols.forEach(([t, d], i) => {
    const x = M + i * 3.05;
    card(s, x, 1.66, 2.85, 2.1, i === 3 ? SAND : "FBF8F2");
    badge(s, i + 1, x + 0.24, 1.86, { d: 0.44, fs: 13 });
    s.addText(t, { x: x + 0.24, y: 2.4, w: 2.4, h: 0.32, fontFace: H, fontSize: 14, bold: true, color: INK, margin: 0 });
    s.addText(d, { x: x + 0.24, y: 2.74, w: 2.4, h: 0.9, fontFace: B, fontSize: 10.5, color: MUTED, margin: 0 });
  });

  card(s, M, 4.0, 5.9, 2.28, DARK);
  s.addText("The scraper tests start a real server", { x: M + 0.3, y: 4.18, w: 5.3, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA, margin: 0 });
  s.addText(
    "A session fixture runs the demo OTA on an OS-assigned free port and the scraper fetches it over loopback. Mocking httpx would exercise parse() and skip robots.txt, status-code mapping, connection reuse and the rate limiter — between them most of what a scraper actually is.",
    { x: M + 0.3, y: 4.54, w: 5.3, h: 1.5, fontFace: B, fontSize: 11.5, color: "D8CFC4", margin: 0 }
  );

  card(s, 6.82, 4.0, 5.89, 2.28, SAND);
  s.addText("A page that renders is an integration test", { x: 7.12, y: 4.18, w: 5.3, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Because the dashboard holds no business logic and reaches the API over HTTP, a page rendering proves the endpoint behind it works and returns the shape expected. The AI Agent page is also tested in the state where its SDK is absent — the state most people will first open it in.",
    { x: 7.12, y: 4.54, w: 5.3, h: 1.5, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );

  s.addNotes(
    "The claim that matters: the suite needs nothing running. In-memory SQLite is only sound because database/models.py deliberately avoids PostgreSQL-only constructs — portable enums as VARCHAR plus CHECK. " +
    "If asked what you would add: property-based tests on the guardrail chain, and a rolling-origin cross-validation instead of the current single-fold backtest."
  );
}

// ==========================================================================
// 19. Bug 1 -- Prophet
// ==========================================================================
{
  const s = slide("It passed every test and was worse than nothing", "Debugging · 1 of 3");

  card(s, M, 1.66, 5.9, 1.7, "FBF8F2");
  s.addText("What it looked like", { x: M + 0.3, y: 1.82, w: 5.3, h: 0.3, fontFace: B, fontSize: 11, bold: true, color: MUTED, margin: 0 });
  s.addText("All green.", { x: M + 0.3, y: 2.12, w: 5.3, h: 0.36, fontFace: H, fontSize: 17, bold: true, color: INK, margin: 0 });
  s.addText("Correct shapes, bounded intervals, clean serialisation — every structural test Prophet had, passing.",
    { x: M + 0.3, y: 2.5, w: 5.3, h: 0.7, fontFace: B, fontSize: 11.5, color: INK, margin: 0 });

  card(s, 6.82, 1.66, 5.89, 1.7, DARK);
  s.addText("What it actually was", { x: 7.12, y: 1.82, w: 5.3, h: 0.3, fontFace: B, fontSize: 11, bold: true, color: "A99C8E", margin: 0 });
  s.addText("66% worse than predicting the mean.", { x: 7.12, y: 2.12, w: 5.3, h: 0.36, fontFace: H, fontSize: 17, bold: true, color: TERRA, margin: 0 });
  s.addText("MAE 0.246 against a 0.148 baseline. R² of −6.5.",
    { x: 7.12, y: 2.5, w: 5.3, h: 0.7, fontFace: B, fontSize: 11.5, color: "D8CFC4", margin: 0 });

  s.addText("The cause", { x: M, y: 3.62, w: W, h: 0.34, fontFace: H, fontSize: 16, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Yearly seasonality fitted on less than one full cycle. With ~365 days the Fourier term is unidentifiable, so it latched onto noise and extrapolated it — confidently.",
    { x: M, y: 3.98, w: 11.4, h: 0.5, fontFace: B, fontSize: 13, color: INK, margin: 0 }
  );

  const fix = [["Yearly seasonality", "OFF below 730 days"], ["Holiday regressors", "OFF below 730 days"], ["Growth", "linear, cps 0.05"]];
  fix.forEach(([k, v], i) => {
    const x = M + i * 3.05;
    card(s, x, 4.56, 2.85, 0.9, SAND);
    s.addText(k, { x: x + 0.2, y: 4.68, w: 2.45, h: 0.3, fontFace: B, fontSize: 11, bold: true, color: INK, margin: 0 });
    s.addText(v, { x: x + 0.2, y: 4.98, w: 2.45, h: 0.34, fontFace: B, fontSize: 11, color: TERRA_D, margin: 0 });
  });
  card(s, M + 9.15, 4.56, 2.94, 0.9, TERRA);
  s.addText("MAE 0.246 → 0.088", { x: M + 9.15, y: 4.56, w: 2.94, h: 0.9, fontFace: H, fontSize: 15, bold: true, color: WHITE, align: "center", valign: "middle", margin: 0 });

  card(s, M, 5.62, W, 0.78, DARK);
  s.addText(
    "The lesson: structural tests prove a model runs. Only a baseline proves it works. Without one I would have shipped a forecaster worse than an average.",
    { x: M + 0.3, y: 5.62, w: 11.4, h: 0.78, fontFace: B, fontSize: 13, bold: true, color: WHITE, valign: "middle", margin: 0 }
  );

  s.addNotes(
    "This is the story to lead with if you only tell one. It has a clean arc and the lesson generalises past this project. " +
    "The measurements are in the model's docstring so nobody 'fixes' the setting back — that detail usually gets a nod. " +
    "Interval coverage went from 0.53 to 0.82 against a nominal 0.80, which is the calibration half of the same fix."
  );
}

// ==========================================================================
// 20. Bug 2 -- merge_asof
// ==========================================================================
{
  const s = slide("Right range, right mean, wrong values", "Debugging · 2 of 3");

  s.addText("The symptom that gave it away", { x: M, y: 1.62, w: 6.4, h: 0.34, fontFace: H, fontSize: 16, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "The gradient booster ranked occupancy below weather_score. That is nonsense — on check-in day the rooms on the books essentially are the answer.",
    { x: M, y: 1.98, w: 6.4, h: 0.66, fontFace: B, fontSize: 12.5, color: INK, margin: 0 }
  );
  s.addText(
    "Looking closer: the booking curve was flat at ~0.48 occupancy at every horizon. Impossible.",
    { x: M, y: 2.62, w: 6.4, h: 0.4, fontFace: B, fontSize: 12.5, bold: true, color: INK, margin: 0 }
  );

  card(s, M, 3.14, 6.4, 1.72, DARK);
  s.addText("The cause", { x: M + 0.3, y: 3.3, w: 5.8, h: 0.3, fontFace: B, fontSize: 11, bold: true, color: "A99C8E", margin: 0 });
  s.addText(
    "pd.merge_asof returns a fresh RangeIndex. Restoring row order with sort_index() therefore re-sorted by position — handing every row some other row's on-the-books total.",
    { x: M + 0.3, y: 3.6, w: 5.8, h: 1.1, fontFace: B, fontSize: 11.5, color: "D8CFC4", margin: 0 }
  );

  card(s, 7.3, 1.62, 5.41, 3.24, SAND);
  s.addText("Why it survived the tests", { x: 7.6, y: 1.8, w: 4.8, h: 0.32, fontFace: H, fontSize: 15, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "The column still had the right range and the right mean — so 10 of the 11 tests in that class passed with the bug in place.",
    { x: 7.6, y: 2.18, w: 4.8, h: 0.7, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );
  s.addText(
    "And the regression test only catches it with VARYING horizons. The fixed-horizon version passes either way, because on identical keys a stable sort is a no-op.",
    { x: 7.6, y: 2.9, w: 4.8, h: 1.0, fontFace: B, fontSize: 11.5, color: INK, margin: 0 }
  );
  s.addText("A test can be present, passing, and asserting nothing.",
    { x: 7.6, y: 3.94, w: 4.8, h: 0.66, fontFace: B, fontSize: 12, bold: true, italic: true, color: TERRA_D, margin: 0 });

  s.addText("After the fix", { x: M, y: 5.06, w: 3.0, h: 0.34, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
  const after = [["MAE", "0.087 → 0.064"], ["R²", "0.591 → 0.765"], ["Top feature", "weather → occupancy"]];
  after.forEach(([k, v], i) => {
    const x = M + 3.0 + i * 3.03;
    card(s, x, 4.98, 2.83, 0.8, i === 2 ? TERRA : SAND);
    s.addText(k, { x: x + 0.18, y: 5.06, w: 2.5, h: 0.28, fontFace: B, fontSize: 10.5, bold: true, color: i === 2 ? "F2E4E0" : MUTED, margin: 0 });
    s.addText(v, { x: x + 0.18, y: 5.32, w: 2.5, h: 0.34, fontFace: B, fontSize: 12.5, bold: true, color: i === 2 ? WHITE : INK, margin: 0 });
  });

  s.addNotes(
    "Use this one with a data-heavy interviewer. 'Right range, right mean, wrong values' is a failure mode they will recognise immediately. " +
    "The deeper point is the second card: I had a test for this behaviour and it was asserting nothing, because its fixture used one horizon for every row. Coverage said the line was tested."
  );
}

// ==========================================================================
// 21. Bug 3 -- robots.txt
// ==========================================================================
{
  const s = slide("A robots.txt check that had been doing nothing", "Debugging · 3 of 3");

  card(s, M, 1.66, 5.9, 2.4, "FBF8F2");
  s.addText("The test I had", { x: M + 0.3, y: 1.84, w: 5.3, h: 0.3, fontFace: B, fontSize: 11, bold: true, color: MUTED, margin: 0 });
  s.addText("\"The scraper fetches an allowed path.\"", { x: M + 0.3, y: 2.14, w: 5.3, h: 0.4, fontFace: H, fontSize: 15, bold: true, color: INK, margin: 0 });
  s.addText("Passing.", { x: M + 0.3, y: 2.54, w: 5.3, h: 0.34, fontFace: B, fontSize: 12.5, color: SAGE, bold: true, margin: 0 });
  s.addText("The test I did not have", { x: M + 0.3, y: 2.98, w: 5.3, h: 0.3, fontFace: B, fontSize: 11, bold: true, color: MUTED, margin: 0 });
  s.addText("\"It refuses a disallowed one.\"", { x: M + 0.3, y: 3.28, w: 5.3, h: 0.4, fontFace: H, fontSize: 15, bold: true, color: TERRA, margin: 0 });
  s.addText("When I wrote it, it failed.", { x: M + 0.3, y: 3.68, w: 5.3, h: 0.3, fontFace: B, fontSize: 12.5, bold: true, color: TERRA_D, margin: 0 });

  card(s, 6.82, 1.66, 5.89, 2.4, DARK);
  s.addText("The cause", { x: 7.12, y: 1.84, w: 5.3, h: 0.3, fontFace: B, fontSize: 11, bold: true, color: "A99C8E", margin: 0 });
  s.addText(
    "urllib.robotparser implements the original 1994 standard, where the FIRST matching rule wins — not Google's longest-match.",
    { x: 7.12, y: 2.14, w: 5.3, h: 0.7, fontFace: B, fontSize: 11.5, color: "D8CFC4", margin: 0 }
  );
  s.addText("Allow: /\nDisallow: /admin", { x: 7.12, y: 2.86, w: 2.5, h: 0.62, fontFace: "Courier New", fontSize: 11, color: TERRA, margin: 0 });
  s.addText(
    "The blanket allow matched first, so the disallow beneath it was dead text. The scraper fetched a path it had been told not to.",
    { x: 9.7, y: 2.86, w: 2.72, h: 1.0, fontFace: B, fontSize: 10.5, color: "D8CFC4", margin: 0 }
  );

  card(s, M, 4.28, W, 1.0, SAND);
  s.addText("The fix", { x: M + 0.3, y: 4.42, w: 1.2, h: 0.3, fontFace: B, fontSize: 11.5, bold: true, color: TERRA_D, margin: 0 });
  s.addText(
    "Specific disallows first, and no blanket Allow: / at all — unmatched paths are permitted by default, so it bought nothing and silently broke the rule beneath it.",
    { x: M + 1.4, y: 4.42, w: 10.3, h: 0.7, fontFace: B, fontSize: 12, color: INK, margin: 0 }
  );

  card(s, M, 5.46, W, 0.86, TERRA);
  s.addText(
    "A test for the happy path proves nothing about a rule whose entire job is to say no.",
    { x: M, y: 5.46, w: W, h: 0.86, fontFace: H, fontSize: 16, bold: true, color: WHITE, align: "center", valign: "middle", margin: 0 }
  );

  s.addNotes(
    "Use this one if the role has any security or data-engineering flavour. It is small, concrete, and the lesson is immediately transferable. " +
    "The uncomfortable part worth admitting: every 'we honour robots.txt' claim in the codebase was false for that path, and the code looked completely correct. " +
    "A fourth bug if they want more: a request guard capped at 400 when the schema made 384 the maximum — it could never fire. The real risk was wall-clock, not count."
  );
}

// ==========================================================================
// 22. Limitations
// ==========================================================================
{
  const s = slide("What it is not, and what comes next", "Honest assessment");

  s.addText("Known limitations", { x: M, y: 1.6, w: 5.9, h: 0.36, fontFace: H, fontSize: 17, bold: true, color: TERRA_D, margin: 0 });
  bullets(s, [
    "One year of synthetic history — not enough to identify yearly seasonality, which is why Prophet's yearly term is off.",
    "No authentication. Which also means the agent's read-only guarantee is in-process rather than a credential.",
    "Single Kafka broker, replication factor 1 — correct for local development, not for production.",
    "POST /models/train is synchronous; at real scale it becomes an enqueue returning 202.",
    "The demo OTA is a real site, but its rates are generated. \"The ingestion path works\", not \"these are the prices in Goa\".",
  ], M, 2.06, 5.9, 3.4, 12);

  s.addText("What I would do next", { x: 6.82, y: 1.6, w: 5.89, h: 0.36, fontFace: H, fontSize: 17, bold: true, color: TERRA_D, margin: 0 });
  const next = [
    ["Two years of history", "The single change that most improves the forecast — it re-enables yearly seasonality"],
    ["Price elasticity", "The engine prices TO forecast demand; it does not model how demand responds to the price it sets"],
    ["Authentication", "Also upgrades the agent's guarantee from in-process to network-level"],
    ["Event extraction agent", "The one LLM use that improves the model rather than the operator experience"],
  ];
  next.forEach(([t, d], i) => {
    const y = 2.06 + i * 0.92;
    badge(s, i + 1, 6.82, y, { d: 0.44, fs: 13 });
    s.addText(t, { x: 7.42, y: y - 0.02, w: 5.3, h: 0.32, fontFace: B, fontSize: 12.5, bold: true, color: INK, margin: 0 });
    s.addText(d, { x: 7.42, y: y + 0.3, w: 5.3, h: 0.5, fontFace: B, fontSize: 10.5, color: MUTED, margin: 0 });
  });

  card(s, M, 5.68, W, 0.72, SAND);
  s.addText(
    "Production-shaped, with a written gap list — which is a stronger claim than \"production-ready\".",
    { x: M, y: 5.68, w: W, h: 0.72, fontFace: B, fontSize: 12.5, bold: true, italic: true, color: TERRA_D, align: "center", valign: "middle", margin: 0 }
  );

  s.addNotes(
    "Never say 'production-ready' about this. Say 'production-shaped, and here is the gap list' — then show it. Volunteering limitations reads as judgement; being caught without them reads as inexperience. " +
    "Have the ordered next-steps ready. Knowing what is missing is different from thinking nothing is."
  );
}

// ==========================================================================
// 23. Closing
// ==========================================================================
{
  const s = darkSlide();
  s.addText("What to remember", { x: M, y: 0.86, w: W, h: 0.6, fontFace: H, fontSize: 34, bold: true, color: WHITE, margin: 0 });

  const points = [
    ["Explainability was the constraint, not a feature", "Every adjustment is named, clamped and logged, because a price nobody can interrogate gets overridden."],
    ["Every metric is quoted against a baseline", "GBR MAE 0.0644 against 0.1430 — 55% better. On a chronological split, never shuffled."],
    ["Guarantees are structural, not conventional", "A price that skipped the guardrails cannot be constructed. The agent cannot reach a write endpoint."],
    ["The bugs are the interesting part", "A model that passed every test and was worse than nothing; a column with the right mean and the wrong values."],
  ];
  points.forEach(([t, d], i) => {
    const y = 1.86 + i * 1.16;
    badge(s, i + 1, M, y, { d: 0.5, fs: 15 });
    s.addText(t, { x: M + 0.72, y: y - 0.04, w: 11.2, h: 0.36, fontFace: H, fontSize: 16, bold: true, color: TERRA, margin: 0 });
    s.addText(d, { x: M + 0.72, y: y + 0.34, w: 11.2, h: 0.52, fontFace: B, fontSize: 12, color: "C9BFB2", margin: 0 });
  });

  s.addText("docker compose up --build     →     localhost:8501", {
    x: M, y: 6.62, w: W, h: 0.4, fontFace: "Courier New", fontSize: 12.5, color: "776A5F", margin: 0,
  });

  s.addNotes(
    "Close on the bugs, not the stack. Anyone can list technologies; very few candidates can describe a defect that was invisible, explain why it was invisible, and say what they changed about their testing as a result. " +
    "If there is time for one question back: ask how they currently handle the explainability problem — every pricing team has one."
  );
}

pres.writeFile({ fileName: "AI_Driven_Hotel_Pricing_System.pptx" }).then((f) => console.log("wrote", f));
