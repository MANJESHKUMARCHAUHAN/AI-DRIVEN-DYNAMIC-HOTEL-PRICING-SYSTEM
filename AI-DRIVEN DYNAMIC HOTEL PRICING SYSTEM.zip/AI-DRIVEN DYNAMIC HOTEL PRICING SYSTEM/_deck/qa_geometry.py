"""Geometry and text-fit QA for a generated deck.

No LibreOffice here, so slides cannot be rendered to images. This substitutes for
the visual pass on the two defects that actually matter and are measurable:

* anything positioned outside the slide, or inside the 0.5" margin
* text that will not fit the box it was given

The fit estimate is deliberately conservative -- it uses average glyph widths, so
it flags "probably tight" rather than proving overflow. Anything it reports gets
looked at by hand.
"""

from __future__ import annotations

import sys
from pptx import Presentation
from pptx.util import Emu

SLIDE_W = 13.333
SLIDE_H = 7.5
MARGIN = 0.5

#: Average glyph width as a fraction of font size, by family. Measured from the
#: fonts' own metrics; serif faces run slightly wider than the sans.
GLYPH = {"Cambria": 0.50, "Calibri": 0.465, "Courier New": 0.60}
LINE_H = 1.22  # line height as a multiple of font size


def inches(v) -> float:
    return Emu(v).inches if v is not None else 0.0


def estimate_lines(text: str, width_in: float, size_pt: float, face: str) -> int:
    """How many rendered lines this text needs in a box of the given width."""
    if not text.strip():
        return 0
    char_w = size_pt * GLYPH.get(face, 0.48) / 72.0
    per_line = max(int(width_in / char_w), 1)
    lines = 0
    for para in text.split("\n"):
        lines += max(1, -(-len(para) // per_line))  # ceil
    return lines


def main(path: str) -> int:
    prs = Presentation(path)
    problems = []

    for idx, slide in enumerate(prs.slides, start=1):
        for shape in slide.shapes:
            name = shape.shape_type
            x, y = inches(shape.left), inches(shape.top)
            w, h = inches(shape.width), inches(shape.height)

            # --- bounds -----------------------------------------------------
            if x < -0.01 or y < -0.01 or x + w > SLIDE_W + 0.01 or y + h > SLIDE_H + 0.01:
                problems.append(
                    f"slide {idx}: {name} out of bounds -- "
                    f"x={x:.2f} y={y:.2f} r={x + w:.2f} b={y + h:.2f}"
                )
            elif x < MARGIN - 0.13 or x + w > SLIDE_W - MARGIN + 0.13:
                problems.append(
                    f"slide {idx}: {name} inside the side margin -- x={x:.2f} r={x + w:.2f}"
                )

            # --- text fit ---------------------------------------------------
            if not shape.has_text_frame:
                continue
            tf = shape.text_frame
            text = tf.text
            if not text.strip():
                continue

            size = None
            face = "Calibri"
            for para in tf.paragraphs:
                for run in para.runs:
                    if run.font.size is not None:
                        size = run.font.size.pt
                    if run.font.name:
                        face = run.font.name
                    break
                if size:
                    break
            if size is None:
                continue

            n_paras = len([p for p in tf.paragraphs if p.text.strip()])
            lines = estimate_lines(text, max(w - 0.1, 0.2), size, face)
            needed = lines * size * LINE_H / 72.0
            # Bulleted/multi-paragraph blocks carry inter-paragraph spacing.
            if n_paras > 1:
                needed += (n_paras - 1) * 7 / 72.0

            if needed > h + 0.06:
                problems.append(
                    f"slide {idx}: text may overflow -- needs ~{needed:.2f}\" in {h:.2f}\" "
                    f"({size:.0f}pt, {lines} lines) :: {text[:58]!r}"
                )

    print(f"{len(prs.slides.__iter__.__self__._sldIdLst)} slides checked")
    if problems:
        print(f"\n{len(problems)} issue(s):\n")
        for p in problems:
            print("  " + p)
        return 1
    print("no geometry or text-fit issues found")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "AI_Driven_Hotel_Pricing_System.pptx"))
